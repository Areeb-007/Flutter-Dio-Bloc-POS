﻿using ITEM_MNG_BO;
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ITEM_MNG_DAL
{
    public class ItemDAL:ItemBDAL
    {
        public void saveItem(ItemBO ib)
        {
            // COnverting the ItemBO in String
            string item = $"{ib.ItemID};{ib.Description};{ib.Price};{ib.Quantity};{ib.CreationDate.ToString("dd/MM/yyyy")}";
            save(item,"Items.txt");
        }
        public List<ItemBO> readItems()
        {
            // Connverting the List of Items of String into ItemBOs
            List<ItemBO> itemsList = new List<ItemBO>();
            List<String> items = new List<String>(read("Items.txt"));
            foreach(string s in items)
            {
                string[] data = s.Split(";");
                ItemBO bo = new ItemBO();
                bo.ItemID =System.Convert.ToInt32( data[0]);
                bo.Description = data[1];
                bo.Price = System.Convert.ToDecimal(data[2]);
                bo.Quantity = System.Convert.ToInt32(data[3]);
                bo.CreationDate = System.Convert.ToDateTime(data[4]);
                itemsList.Add(bo);
            }
            return itemsList;
        }

        public void deleteFile()
        {
            delete("Items.txt");
        }
    }
}
