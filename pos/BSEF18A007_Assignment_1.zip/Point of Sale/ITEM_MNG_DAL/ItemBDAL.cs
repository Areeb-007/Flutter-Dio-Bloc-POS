﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ITEM_MNG_DAL
{
    public class ItemBDAL
    {
        internal void save(string item,string fileName)
        {
            // Saving the strings to the file 
            string itemFile = Path.Combine(Environment.CurrentDirectory, fileName);
            StreamWriter sw = new StreamWriter(itemFile, append: true);
            sw.WriteLine(item);
            sw.Close();
        }
        internal List<String> read(string fileName)
        {
            // reading the Items from the file in the form of string
            List<string> itemList = new List<string>();
            string filePath = Path.Combine(Environment.CurrentDirectory,fileName);
            StreamReader sr = new StreamReader(filePath);
            string line = String.Empty;
            while ((line = sr.ReadLine()) != null)
            {

                itemList.Add(line);

            }
            sr.Close();
            return itemList;
        }

        internal void delete(string fileName)
        {
            // deleting the file 
            if(File.Exists(fileName)== true)
            {
                File.Delete(fileName);
            }
            else
            {
                Console.WriteLine("File Not Exist");
            }
        }
    }
}
