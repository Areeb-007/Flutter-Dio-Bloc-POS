﻿using ITEM_KEY_GEN;
using ITEM_MNG_BO;
using ITEM_MNG_DAL;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITEM_MNG_BL
{
    public class ItemBL
    {
        public void saveItem(ItemBO ibo)
        {
            // Just to make sure the saving of Item
            Console.WriteLine("Do you want to save this Item? (Yes/No)");
            string choice = Console.ReadLine();
            if(choice.Equals("Yes")|| choice.Equals("yes"))
            {
                ItemKey key = new ItemKey();
                // Creation Date is provided on the saving time
                ibo.CreationDate = DateTime.Now.Date;
                // Item ID is also generated on the saving time
                ibo.ItemID = key.generateKey();
                ibo.displayItem();
                ItemDAL idal = new ItemDAL();
                idal.saveItem(ibo);
                Console.WriteLine("Item Saved Successfully.");
            }
            else
            {
                Console.WriteLine("Cancelled!");
            }
            
        }
        public ItemBO find(int id)
        {
            // Finding Item on the basis of ItemID
            ItemDAL itemDal = new ItemDAL();
            ItemBO ibo=new ItemBO();
            List<ItemBO> itemsList = new List<ItemBO>(itemDal.readItems());
            foreach(ItemBO bo in itemsList)
            {
                if(bo.ItemID==id)
                {
                    return bo;
                }
            }
            return ibo;
        }

        public void updateItem(int id,ItemBO bo)
        {
            // update item on the basis of Id and update that Item with ItemBO
            Console.WriteLine("Do you want to save this Item? (Yes/No)");
            string choice = Console.ReadLine();
            if (choice.Equals("Yes") || choice.Equals("yes"))
            {
                ItemDAL itemDal = new ItemDAL();
                bo.ItemID = id;
                bo.CreationDate = DateTime.Now.Date;
                List<ItemBO> items = new List<ItemBO>(itemDal.readItems());
                foreach(ItemBO bo2 in items)
                {
                    // If some attribute is not given then it is default so these will not be updated
                    if(bo2.ItemID==id)
                    {
                        if(bo.Description != "")
                        {
                            bo2.Description = bo.Description;
                        }
                        if(bo.Price!=default(decimal))
                        {
                            bo2.Price = bo.Price;
                        }
                        if(bo.Quantity!=default(int))
                        {
                            bo2.Quantity = bo.Quantity;
                        }
                    }
                }

                // to update the file we create a new file and update it and then delete the old file 
                itemDal.deleteFile();
                foreach(ItemBO bo3 in items)
                {
                    itemDal.saveItem(bo3);
                }
            }
            else
            {
                Console.WriteLine("Cancelled!");
            }
        }
        public List<ItemBO> readItems()
        {
            // read Items from File
            ItemDAL itemDAL = new ItemDAL();
            return itemDAL.readItems();
        }
        public void deleteItem(int id)
        {
            // Confirming the deletion o Item
            Console.WriteLine("Do you want to Remove this Item? (Yes/No)");
            string choice = Console.ReadLine();
            if (choice.Equals("Yes") || choice.Equals("yes"))
            {

                ItemDAL itemDal = new ItemDAL();
                List<ItemBO> itemsList = new List<ItemBO>(itemDal.readItems());
                List<ItemBO> newItemsList = new List<ItemBO>();
                foreach(ItemBO ib in itemsList)
                {
                    //If ItemID match to the Item ID Which is to be deleted then it is not copied
                    if(ib.ItemID!=id)
                    {
                        newItemsList.Add(ib);
                    }
                }

               // Deleting the old file and saving the new file
                itemDal.deleteFile();
                foreach (ItemBO ibo2 in newItemsList)
                {
                    itemDal.saveItem(ibo2);
                }
            }
            else
            {
                Console.WriteLine("Cancelled!");
            }
        }

        public List<ItemBO> findItems(ItemBO bo)
        {
            // Find Items on the basis of the ItemBO
            ItemDAL itemDal = new ItemDAL();
            List<ItemBO> itemsList = new List<ItemBO>(itemDal.readItems());
            List<ItemBO> itemsFound = new List<ItemBO>();
            
            // there are 32 combinations for searching an Item on any of 5 attributes present in ItemBO
            foreach (ItemBO ibo in itemsList)
            {
               // Combinations - 1
               if((bo.ItemID!=default(int))&&(bo.Description!=default(string))&&(bo.Price!=default(decimal))&&(bo.Quantity!=default(int))&&(bo.CreationDate!=default(DateTime)))
                {
                    if((bo.ItemID == ibo.ItemID) && (bo.Description == ibo.Description) && (bo.Price == ibo.Price) && (bo.Quantity == ibo.Quantity) && (bo.CreationDate == ibo.CreationDate))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 2
                if ((bo.ItemID != default(int)) && (bo.Description != default(string)) && (bo.Price != default(decimal)) && (bo.Quantity != default(int)) && (bo.CreationDate == default(DateTime)))
                {
                    if ((bo.ItemID == ibo.ItemID) && (bo.Description == ibo.Description) && (bo.Price == ibo.Price) && (bo.Quantity == ibo.Quantity) )
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 3
                if ((bo.ItemID != default(int)) && (bo.Description != default(string)) && (bo.Price != default(decimal)) && (bo.Quantity == default(int)) && (bo.CreationDate != default(DateTime)))
                {
                    if ((bo.ItemID == ibo.ItemID) && (bo.Description == ibo.Description) && (bo.Price == ibo.Price) && (bo.CreationDate == ibo.CreationDate))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 4
                if ((bo.ItemID != default(int)) && (bo.Description != default(string)) && (bo.Price != default(decimal)) && (bo.Quantity == default(int)) && (bo.CreationDate == default(DateTime)))
                {
                    if ((bo.ItemID == ibo.ItemID) && (bo.Description == ibo.Description) && (bo.Price == ibo.Price))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 5
                if ((bo.ItemID != default(int)) && (bo.Description != default(string)) && (bo.Price == default(decimal)) && (bo.Quantity != default(int)) && (bo.CreationDate != default(DateTime)))
                {
                    if ((bo.ItemID == ibo.ItemID) && (bo.Description == ibo.Description) && (bo.Quantity == ibo.Quantity) && (bo.CreationDate == ibo.CreationDate))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 6
                if ((bo.ItemID != default(int)) && (bo.Description != default(string)) && (bo.Price == default(decimal)) && (bo.Quantity != default(int)) && (bo.CreationDate == default(DateTime)))
                {
                    if ((bo.ItemID == ibo.ItemID) && (bo.Description == ibo.Description) && (bo.Quantity == ibo.Quantity) )
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 7
                if ((bo.ItemID != default(int)) && (bo.Description != default(string)) && (bo.Price == default(decimal)) && (bo.Quantity == default(int)) && (bo.CreationDate != default(DateTime)))
                {
                    if ((bo.ItemID == ibo.ItemID) && (bo.Description == ibo.Description) &&  (bo.CreationDate == ibo.CreationDate))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 8
                if ((bo.ItemID != default(int)) && (bo.Description != default(string)) && (bo.Price == default(decimal)) && (bo.Quantity == default(int)) && (bo.CreationDate == default(DateTime)))
                {
                    if ((bo.ItemID == ibo.ItemID) && (bo.Description == ibo.Description) )
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 9
                if ((bo.ItemID != default(int)) && (bo.Description == default(string)) && (bo.Price != default(decimal)) && (bo.Quantity != default(int)) && (bo.CreationDate != default(DateTime)))
                {
                    if ((bo.ItemID == ibo.ItemID) && (bo.Price == ibo.Price) && (bo.Quantity == ibo.Quantity) && (bo.CreationDate == ibo.CreationDate))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 10
                if ((bo.ItemID != default(int)) && (bo.Description == default(string)) && (bo.Price != default(decimal)) && (bo.Quantity != default(int)) && (bo.CreationDate == default(DateTime)))
                {
                    if ((bo.ItemID == ibo.ItemID)  && (bo.Price == ibo.Price) && (bo.Quantity == ibo.Quantity))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 11
                if ((bo.ItemID != default(int)) && (bo.Description == default(string)) && (bo.Price != default(decimal)) && (bo.Quantity == default(int)) && (bo.CreationDate != default(DateTime)))
                {
                    if ((bo.ItemID == ibo.ItemID) && (bo.Price == ibo.Price) && (bo.CreationDate == ibo.CreationDate))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 12
                if ((bo.ItemID != default(int)) && (bo.Description == default(string)) && (bo.Price != default(decimal)) && (bo.Quantity == default(int)) && (bo.CreationDate == default(DateTime)))
                {
                    if ((bo.ItemID == ibo.ItemID)  && (bo.Price == ibo.Price))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 13
                if ((bo.ItemID != default(int)) && (bo.Description == default(string)) && (bo.Price == default(decimal)) && (bo.Quantity != default(int)) && (bo.CreationDate != default(DateTime)))
                {
                    if ((bo.ItemID == ibo.ItemID)  && (bo.Quantity == ibo.Quantity) && (bo.CreationDate == ibo.CreationDate))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 14
                if ((bo.ItemID != default(int)) && (bo.Description == default(string)) && (bo.Price == default(decimal)) && (bo.Quantity != default(int)) && (bo.CreationDate == default(DateTime)))
                {
                    if ((bo.ItemID == ibo.ItemID) && (bo.Quantity == ibo.Quantity))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 15
                if ((bo.ItemID != default(int)) && (bo.Description == default(string)) && (bo.Price == default(decimal)) && (bo.Quantity == default(int)) && (bo.CreationDate != default(DateTime)))
                {
                    if ((bo.ItemID == ibo.ItemID) && (bo.CreationDate == ibo.CreationDate))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 16
                if ((bo.ItemID != default(int)) && (bo.Description == default(string)) && (bo.Price == default(decimal)) && (bo.Quantity == default(int)) && (bo.CreationDate == default(DateTime)))
                {
                    if ((bo.ItemID == ibo.ItemID))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 17
                if ((bo.ItemID == default(int)) && (bo.Description != default(string)) && (bo.Price != default(decimal)) && (bo.Quantity != default(int)) && (bo.CreationDate != default(DateTime)))
                {
                    if ((bo.Description == ibo.Description) && (bo.Price == ibo.Price) && (bo.Quantity == ibo.Quantity) && (bo.CreationDate == ibo.CreationDate))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 18
                if ((bo.ItemID==default(int))&&(bo.Description != default(string)) && (bo.Price != default(decimal)) && (bo.Quantity != default(int)) && (bo.CreationDate == default(DateTime)))
                {
                    if ((bo.Description == ibo.Description) && (bo.Price == ibo.Price) && (bo.Quantity == ibo.Quantity))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 19
                if ((bo.ItemID == default(int)) && (bo.Description != default(string)) && (bo.Price != default(decimal)) && (bo.Quantity == default(int)) && (bo.CreationDate != default(DateTime)))
                {
                    if ((bo.Description == ibo.Description) && (bo.Price == ibo.Price) && (bo.CreationDate == ibo.CreationDate))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 20
                if ((bo.ItemID == default(int)) && (bo.Description != default(string)) && (bo.Price != default(decimal)) && (bo.Quantity == default(int)) && (bo.CreationDate == default(DateTime)))
                {
                    if ((bo.Description == ibo.Description) && (bo.Price == ibo.Price))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 21
                if ((bo.ItemID == default(int)) && (bo.Description != default(string)) && (bo.Price == default(decimal)) && (bo.Quantity != default(int)) && (bo.CreationDate != default(DateTime)))
                {
                    if ( (bo.Description == ibo.Description) && (bo.Quantity == ibo.Quantity) && (bo.CreationDate == ibo.CreationDate))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 22
                if ((bo.ItemID == default(int)) && (bo.Description != default(string)) && (bo.Price == default(decimal)) && (bo.Quantity != default(int)) && (bo.CreationDate == default(DateTime)))
                {
                    if ( (bo.Description == ibo.Description) && (bo.Quantity == ibo.Quantity))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 23
                if ((bo.ItemID == default(int)) && (bo.Description != default(string)) && (bo.Price == default(decimal)) && (bo.Quantity == default(int)) && (bo.CreationDate != default(DateTime)))
                {
                    if ((bo.Description == ibo.Description) && (bo.CreationDate == ibo.CreationDate))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 24
                if ((bo.ItemID == default(int)) && (bo.Description != default(string)) && (bo.Price == default(decimal)) && (bo.Quantity == default(int)) && (bo.CreationDate == default(DateTime)))
                {
                    if ((bo.Description == ibo.Description))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 25
                if ((bo.ItemID == default(int)) && (bo.Description == default(string)) && (bo.Price != default(decimal)) && (bo.Quantity != default(int)) && (bo.CreationDate != default(DateTime)))
                {
                    if ((bo.Price == ibo.Price) && (bo.Quantity == ibo.Quantity) && (bo.CreationDate == ibo.CreationDate))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 26
                if ((bo.ItemID == default(int)) && (bo.Description == default(string)) && (bo.Price != default(decimal)) && (bo.Quantity != default(int)) && (bo.CreationDate == default(DateTime)))
                {
                    if ((bo.Price == ibo.Price) && (bo.Quantity == ibo.Quantity))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 27
                if ((bo.ItemID == default(int)) && (bo.Description == default(string)) && (bo.Price != default(decimal)) && (bo.Quantity == default(int)) && (bo.CreationDate != default(DateTime)))
                {
                    if ((bo.Price == ibo.Price) && (bo.CreationDate == ibo.CreationDate))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 28
                if ((bo.ItemID == default(int)) && (bo.Description == default(string)) && (bo.Price != default(decimal)) && (bo.Quantity == default(int)) && (bo.CreationDate == default(DateTime)))
                {
                    if ((bo.Price == ibo.Price))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 29
                if ((bo.ItemID == default(int)) && (bo.Description == default(string)) && (bo.Price == default(decimal)) && (bo.Quantity != default(int)) && (bo.CreationDate != default(DateTime)))
                {
                    if ((bo.Quantity == ibo.Quantity) && (bo.CreationDate == ibo.CreationDate))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 30
                if ((bo.ItemID == default(int)) && (bo.Description == default(string)) && (bo.Price == default(decimal)) && (bo.Quantity != default(int)) && (bo.CreationDate == default(DateTime)))
                {
                    if ((bo.Quantity == ibo.Quantity))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 31
                if ((bo.ItemID == default(int)) && (bo.Description == default(string)) && (bo.Price == default(decimal)) && (bo.Quantity == default(int)) && (bo.CreationDate != default(DateTime)))
                {
                    if ((bo.CreationDate == ibo.CreationDate))
                    {
                        itemsFound.Add(ibo);
                    }
                }
                // Combinations - 32
                if ((bo.ItemID == default(int)) && (bo.Description == default(string)) && (bo.Price == default(decimal)) && (bo.Quantity == default(int)) && (bo.CreationDate == default(DateTime)))
                {
                    
                }

            }
            return itemsFound;
        }

        
    }
}
