﻿using CUS_KEY_GEN;
using CUS_MNG_BO;
using CUST_MNG_DAL;
using System;
using System.Collections.Generic;
using System.Text;

namespace CUS_MNG_BL
{
    public class CustomerBL
    {
        public void saveCustomer(CustomerBO cbo)
        {
            Console.WriteLine("Do you want to save this Item? (Yes/No)");
            string choice = Console.ReadLine();
            if (choice.Equals("Yes") || choice.Equals("yes"))
            {
                CustomerKey customerKey = new CustomerKey();
                cbo.CustomerID = customerKey.generateKey();
                cbo.displayItem();

                CustomerDAL cdal = new CustomerDAL();
                cdal.saveItem(cbo);
                Console.WriteLine("Item Saved Successfully.");
            }
            else
            {
                Console.WriteLine("Cancelled!");
            }

        }
        public CustomerBO find(int id)
        {
            CustomerDAL customerDal = new CustomerDAL();
            CustomerBO ibo = new CustomerBO();
            List<CustomerBO> itemsList = new List<CustomerBO>(customerDal.readItems());
            foreach (CustomerBO bo in itemsList)
            {
                if (bo.CustomerID == id)
                {
                    return bo;
                }
            }
            return ibo;
        }

        public void deleteItem(int id)
        {
            Console.WriteLine("Do you want to Remove this Item? (Yes/No)");
            string choice = Console.ReadLine();
            if (choice.Equals("Yes") || choice.Equals("yes"))
            {

                CustomerDAL customerDal = new CustomerDAL();
                List<CustomerBO> customersList = new List<CustomerBO>(customerDal.readItems());
                List<CustomerBO> newCustomersList = new List<CustomerBO>();
                foreach (CustomerBO cbo in customersList)
                {
                    if (cbo.CustomerID != id)
                    {
                        newCustomersList.Add(cbo);
                    }
                }
                customerDal.deleteFile();
                foreach (CustomerBO cbo2 in newCustomersList)
                {
                    customerDal.saveItem(cbo2);
                }
            }
            else
            {
                Console.WriteLine("Cancelled!");
            }
        }
        public void updateCustomer(int id, CustomerBO bo)
        {
            // Updating the Customer File and then deleting the old Customer File 

            Console.WriteLine("Do you want to save this Item? (Yes/No)");
            string choice = Console.ReadLine();
            if (choice.Equals("Yes") || choice.Equals("yes"))
            {
                CustomerDAL customerDal = new CustomerDAL();
                bo.CustomerID = id;
                // IF the User Leaves Its Blank then the attribute will be set with default values
                List<CustomerBO> customers = new List<CustomerBO>(customerDal.readItems());
                foreach (CustomerBO bo2 in customers)
                {
                    if (bo2.CustomerID == id)
                    {
                        if (bo.Name !=default(string))
                        {
                            bo2.Name = bo.Name;
                        }
                        if (bo.Address != default(string))
                        {
                            bo2.Address = bo.Address;
                        }
                        if (bo.Phone != default(string))
                        {
                            bo2.Phone = bo.Phone;
                        }
                        if(bo.Email!=default(string))
                        {
                            bo2.Email = bo.Email;
                        }
                        if(bo.AmountPayable!= default(decimal))
                        {
                            bo2.AmountPayable = bo.AmountPayable;
                        }
                        if (bo.SaleLimit != default(decimal))
                        {
                            bo2.SaleLimit = bo.SaleLimit;
                        }
                    }
                }
                customerDal.deleteFile();
                foreach (CustomerBO bo3 in customers)
                {
                    customerDal.saveItem(bo3);
                }
            }
            else
            {
                Console.WriteLine("Cancelled!");
            }
        }
        public List<CustomerBO> findItems(CustomerBO bo)
        {
            CustomerDAL customerDal = new CustomerDAL();
            List<CustomerBO> customersList = new List<CustomerBO>(customerDal.readItems());
            List<CustomerBO> customersFound = new List<CustomerBO>();

            // There are 128 combinations for searching on the basis of 7 attributes of CustomerBO
            foreach (CustomerBO cbo in customersList)
            {
                // Combinations - 1
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal))&& (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 2
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 3
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email)  && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 4
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) )
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 5
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone)  && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 6
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone)  && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 7
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone)  && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 8
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) )
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 9
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Address == cbo.Address)  && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 10
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Address == cbo.Address)  && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 11
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Address == cbo.Address)  && (bo.Email == cbo.Email) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 12
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Address == cbo.Address)  && (bo.Email == cbo.Email))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 13
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 14
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Address == cbo.Address)  && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 15
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Address == cbo.Address)  && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 16
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Address == cbo.Address))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 17
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 18
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 19
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name)  && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 20
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 21
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Phone == cbo.Phone) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 22
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Phone == cbo.Phone) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 23
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name)  && (bo.Phone == cbo.Phone) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 24
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Phone == cbo.Phone))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 25
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 26
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name)  && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 27
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name) && (bo.Email == cbo.Email) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 28
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name)  && (bo.Email == cbo.Email))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 29
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name)  && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 30
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name)  && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 31
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name)  && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 32
                if ((bo.CustomerID != default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Name == cbo.Name))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 1
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID)  && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 2
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID)  && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 3
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 4
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID)  && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 5
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 6
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 7
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID)  && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 8
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 9
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Address == cbo.Address) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 10
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Address == cbo.Address) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 11
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Address == cbo.Address) && (bo.Email == cbo.Email) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 12
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Address == cbo.Address) && (bo.Email == cbo.Email))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 13
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID)  && (bo.Address == cbo.Address) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 14
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Address == cbo.Address) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 15
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Address == cbo.Address) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 16
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Address == cbo.Address))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 17
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 18
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 19
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 20
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 21
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Phone == cbo.Phone) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 22
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Phone == cbo.Phone) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 23
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Phone == cbo.Phone) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 24
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Phone == cbo.Phone))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 25
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 26
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 27
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Email == cbo.Email) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 28
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.Email == cbo.Email))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 29
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 30
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 31
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 32
                if ((bo.CustomerID != default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.CustomerID == cbo.CustomerID))
                    {
                        customersFound.Add(cbo);
                    }
                }



                //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                // Combinations - 1
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 2
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 3
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 4
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 5
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 6
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 7
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ( (bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 8
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ( (bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Phone == cbo.Phone))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 9
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 10
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 11
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Email == cbo.Email) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 12
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.Email == cbo.Email))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 13
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 14
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 15
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Address == cbo.Address) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 16
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Address == cbo.Address))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 17
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 18
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 19
                if ((bo.CustomerID== default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 20
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 21
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Phone == cbo.Phone) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 22
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Phone == cbo.Phone) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 23
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Phone == cbo.Phone) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 24
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Phone == cbo.Phone))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 25
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 26
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 27
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Email == cbo.Email) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 28
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.Email == cbo.Email))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 29
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 30
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 31
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Name == cbo.Name) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 32
                if ((bo.CustomerID == default(int)) && (bo.Name != default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Name == cbo.Name))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 1
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 2
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 3
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 4
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.Email == cbo.Email))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 5
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 6
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 7
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Address == cbo.Address) && (bo.Phone == cbo.Phone) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 8
                if ((bo.CustomerID== default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Address == cbo.Address) && (bo.Phone == cbo.Phone))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 9
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Address == cbo.Address) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 10
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Address == cbo.Address) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 11
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Address == cbo.Address) && (bo.Email == cbo.Email) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 12
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Address == cbo.Address) && (bo.Email == cbo.Email))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 13
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Address == cbo.Address) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 14
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Address == cbo.Address) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 15
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Address == cbo.Address) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 16
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address != default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Address == cbo.Address))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 17
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 18
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 19
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Phone == cbo.Phone) && (bo.Email == cbo.Email) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 20
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Phone == cbo.Phone) && (bo.Email == cbo.Email))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 21
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Phone == cbo.Phone) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 22
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Phone == cbo.Phone) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 23
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Phone == cbo.Phone) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 24
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone != default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Phone == cbo.Phone))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 25
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 26
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.Email == cbo.Email) && (bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 27
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.Email == cbo.Email) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 28
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email != default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ( (bo.Email == cbo.Email))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 29
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.AmountPayable == cbo.AmountPayable) && (bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 30
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable != default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    if ((bo.AmountPayable == cbo.AmountPayable))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 31
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit != default(decimal)))
                {
                    if ((bo.SaleLimit == cbo.SaleLimit))
                    {
                        customersFound.Add(cbo);
                    }
                }
                // Combinations - 32
                if ((bo.CustomerID == default(int)) && (bo.Name == default(string)) && (bo.Address == default(string)) && (bo.Phone == default(string)) && (bo.Email == default(string)) && (bo.AmountPayable == default(decimal)) && (bo.SaleLimit == default(decimal)))
                {
                    
                }
            }
            return customersFound;
        }
    }
}
