﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SALE_LINE_ITEM_BO
{
    public class SaleLineItemBO
    {
        private int lineNo;
        private int orderID;
        private int itemID;
        private int quantity;
        private decimal amount;

        public int LineNo
        {
            get
            {
                return this.lineNo;
            }
            set
            {
                this.lineNo = value;
            }
        }

        public int OrderID
        {
            get
            {
                return this.orderID;
            }
            set
            {
                this.orderID = value;
            }
        }

        public int ItemID
        {
            get
            {
                return this.itemID;
            }
            set
            {
                this.itemID = value;
            }
        }
        public int Quantity
        {
            get
            {
                return this.quantity;
            }
            set
            {
                this.quantity = value;
            }
        }
        public decimal Amount
        {
            get
            {
                return this.amount;
            }
            set
            {
                this.amount = value;
            }
        }

    }
}
