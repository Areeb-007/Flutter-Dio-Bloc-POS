﻿using CUS_MNG_BL;
using CUS_MNG_BO;
using ITEM_MNG_BL;
using ITEM_MNG_BO;
using SALE_LINE_ITEM_BO;
using SALE_LINE_ITEM_MNG_DAL;
using SALE_MNG_BO;
using System;
using System.Collections.Generic;
using System.Text;

namespace SALE_LINE_ITEM_BL
{
    public class SaleLineItemBL
    {
        
        public decimal calculateTotalAmount(List<SaleLineItemBO> saleLineItems)
        {
            // Total Amount Calculation
            decimal amount = 0;
            foreach(SaleLineItemBO saleLineItemBO in saleLineItems)
            {
                amount = amount + saleLineItemBO.Amount;
            }
            return amount;
        }
        public List<SaleLineItemBO> removeItem(List<SaleLineItemBO> saleLineItems,int id)
        {
            //Removing the Item on the basis of Item ID
            List<SaleLineItemBO> newSaleLineItems = new List<SaleLineItemBO>();
            foreach(SaleLineItemBO slbo in saleLineItems)
            {
                if(slbo.ItemID!=id)
                {
                    newSaleLineItems.Add(slbo);
                }
            }
            return newSaleLineItems;
        }
        public void saveSaleLineItem(SaleLineItemBO saleLineItemBO)
        {
            // Save SaleLineItem
            SaleLineItemDAL saleLineItemDAL = new SaleLineItemDAL();
            ItemBL itemBL = new ItemBL();
            ItemBO itemBO = itemBL.find(saleLineItemBO.ItemID);
            itemBO.Quantity = itemBO.Quantity - saleLineItemBO.Quantity;
            itemBL.updateItem(itemBO.ItemID, itemBO);
            saleLineItemDAL.saveSaleLineItem(saleLineItemBO);
        }
        public List<SaleLineItemBO> readSaleLineItem()
        {
            // Read Sale line Items
            List<SaleLineItemBO> saleLineItemList = new List<SaleLineItemBO>();
            SaleLineItemDAL saleLineItemDAL = new SaleLineItemDAL();
            saleLineItemList = saleLineItemDAL.readSaleLineItems();
            return saleLineItemList;
        }

        public bool isSaleIdExist(int saleID)
        {
            // To check wether the SaleID exist
            List<SaleLineItemBO> saleLineItems = readSaleLineItem();
            foreach(SaleLineItemBO saleLineItem in saleLineItems)
            {
                if(saleLineItem.OrderID==saleID)
                {
                    return true;
                }
            }
            return false;
        }

        public List<SaleLineItemBO> getSaleLineItemsForOrderID(int orderID)
        {
            // to get the sale line item on the basis of OrderID/SaleID
            List<SaleLineItemBO> saleLineItemBOs = new List<SaleLineItemBO>();
            List<SaleLineItemBO> oldSaleLineItems = readSaleLineItem();
            foreach(SaleLineItemBO saleLineItem in oldSaleLineItems)
            {
                if(saleLineItem.OrderID==orderID)
                {
                    saleLineItemBOs.Add(saleLineItem);
                }
            }
            return saleLineItemBOs;
        }
    }
}
