﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace CUS_KEY_GEN
{
    public class CustomerKey
    {

        private string file = Path.Combine(Environment.CurrentDirectory, "CustomerKey.txt");
        private int key;
        private void writeNewKey(int key)
        {

            StreamWriter sw = new StreamWriter(file, append: true);
            sw.WriteLine(key);
            sw.Close();
        }
        private int getKey()
        {
            if (File.Exists(file) == true)
            {
                StreamReader sr = new StreamReader(file);
                string line = sr.ReadLine();
                while ((line = sr.ReadLine()) != null)
                {

                    key = System.Convert.ToInt32(line);

                }
                sr.Close();
            }
            else
            {
                writeNewKey(199);
                key = 199;
            }
            return key;
        }

        public int generateKey()
        {
            key = getKey();
            writeNewKey(++key);
            return key;
        }
    }
}
