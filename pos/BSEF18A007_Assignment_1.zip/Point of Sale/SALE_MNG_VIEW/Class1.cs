﻿using System;

namespace SALE_MNG_VIEW
{
    public class Class1
    {
    }
}
