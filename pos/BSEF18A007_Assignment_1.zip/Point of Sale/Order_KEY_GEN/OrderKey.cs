﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Order_KEY_GEN
{
    public class OrderKey
    {
        private string file = Path.Combine(Environment.CurrentDirectory, "OrderKey.txt");
        private int key;
        

        private void writeNewKey(int key)
        {

            StreamWriter sw = new StreamWriter(file, append: true);
            sw.WriteLine(key);
            sw.Close();
        }
        private int getKey()
        {
            if (File.Exists(file) == true)
            {
                StreamReader sr = new StreamReader(file);
                string line = sr.ReadLine();
                while ((line = sr.ReadLine()) != null)
                {

                    key = System.Convert.ToInt32(line);

                }
                sr.Close();
            }
            else
            {
                writeNewKey(299);
                key = 299;
            }
            return key;
        }

        public int generateKey()
        {
            key = getKey();
            writeNewKey(++key);
            return key;
        }
    }
}
