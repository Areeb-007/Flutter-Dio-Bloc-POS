﻿using CUS_MNG_BO;
using System;
using System.Collections.Generic;
using System.Text;

namespace CUST_MNG_DAL
{
    public class CustomerDAL:CustomerBDAL
    {
        public void saveItem(CustomerBO cbo)
        { 
            // Converting the CustomerBO in string 
            string customer = $"{cbo.CustomerID};{cbo.Name};{cbo.Address};{cbo.Phone};{cbo.Email};{cbo.AmountPayable};{cbo.SaleLimit}";
            save(customer, "Customers.txt");
        }
        public List<CustomerBO> readItems()
        {
            List<CustomerBO> customersList = new List<CustomerBO>();
            List<String> items = new List<String>(read("Customers.txt"));
            foreach (string s in items)
            {
                string[] data = s.Split(";");
                CustomerBO bo = new CustomerBO();
                bo.CustomerID = System.Convert.ToInt32(data[0]);
                bo.Name = data[1];
                bo.Address = data[2];
                bo.Phone = data[3];
                bo.Email = data[4];
                bo.AmountPayable = System.Convert.ToDecimal(data[5]);
                bo.SaleLimit = System.Convert.ToDecimal(data[6]);
                customersList.Add(bo);
            }
            return customersList;
        }

        public void deleteFile()
        {
            delete("Customers.txt");
        }
    }
}
