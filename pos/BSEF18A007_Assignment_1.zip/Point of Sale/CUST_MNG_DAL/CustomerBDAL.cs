﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace CUST_MNG_DAL
{
    public class CustomerBDAL
    {
        internal void save(string customer, string fileName)
        {
            string itemFile = Path.Combine(Environment.CurrentDirectory, fileName);
            StreamWriter sw = new StreamWriter(itemFile, append: true);
            sw.WriteLine(customer);
            sw.Close();
        }
        internal List<String> read(string fileName)
        {
            List<string> customerList = new List<string>();
            string filePath = Path.Combine(Environment.CurrentDirectory, fileName);
            StreamReader sr = new StreamReader(filePath);
            string line = String.Empty;
            while ((line = sr.ReadLine()) != null)
            {

                customerList.Add(line);

            }
            sr.Close();
            return customerList;
        }

        internal void delete(string fileName)
        {
            if (File.Exists(fileName) == true)
            {
                File.Delete(fileName);
            }
            else
            {
                Console.WriteLine("File Not Exist");
            }
        }
    }
}
