﻿using SALE_MNG_BO;
using System;
using System.Collections.Generic;
using System.Text;

namespace SALE_MNG_DAL
{
    public class SaleDAL:SaleBDAL
    {
        public void saveSale(SaleBO saleBO)
        {
            // saving the sale Business Object in the form of string
            string sale = $"{saleBO.OrderID};{saleBO.CustomerID};{saleBO.SaleDate};{saleBO.Status}";
            save(sale,"Sales.txt");
        }
        public List<SaleBO> readSales()
        {
            //Reading the sale Business Object in the form of string and then converting it in Businsess Object
            List<SaleBO> salesList = new List<SaleBO>();
            List<String> items = new List<String>(read("Sales.txt"));
            foreach (string s in items)
            {
                string[] data = s.Split(";");
                SaleBO sbo = new SaleBO();
                sbo.OrderID = System.Convert.ToInt32(data[0]);
                sbo.CustomerID = System.Convert.ToInt32(data[1]);
                sbo.SaleDate = System.Convert.ToDateTime(data[2]);
                sbo.Status = Convert.ToBoolean(data[3]);
                salesList.Add(sbo);
            }
            return salesList;
        }
    }
}
