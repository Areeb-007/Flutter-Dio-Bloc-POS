﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace SALE_MNG_DAL
{
    public class SaleBDAL
    {
        internal void save(string item, string fileName)
        {
            // saving the recieved in the file 
            string itemFile = Path.Combine(Environment.CurrentDirectory, fileName);
            StreamWriter sw = new StreamWriter(itemFile, append: true);
            sw.WriteLine(item);
            sw.Close();
        }
        internal List<String> read(string fileName)
        {
            // read the data from the files
            List<string> saleList = new List<string>();
            string filePath = Path.Combine(Environment.CurrentDirectory, fileName);
            StreamReader sr = new StreamReader(filePath);
            string line = String.Empty;
            while ((line = sr.ReadLine()) != null)
            {

                saleList.Add(line);

            }
            sr.Close();
            return saleList;
        }

        internal void delete(string fileName)
        {
            // delete the file 
            if (File.Exists(fileName) == true)
            {
                File.Delete(fileName);
            }
            else
            {
                Console.WriteLine("File Not Exist");
            }
        }
    }
}
