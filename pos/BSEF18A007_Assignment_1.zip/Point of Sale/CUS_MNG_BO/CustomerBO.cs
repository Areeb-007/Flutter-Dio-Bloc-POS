﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CUS_MNG_BO
{
    public class CustomerBO
    {
        private int customerID;
        private string name;
        private string address;
        private string phone;
        private string email;
        private decimal amountPayable;
        private decimal saleLimit;

        public int CustomerID
        {
            get
            {
                return this.customerID;
            }
            set
            {
                this.customerID = value;
            }
        }


        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }
        public string Address
        {
            get
            {
                return this.address;
            }
            set
            {
                this.address = value;
            }
        }
        public string Phone
        {
            get
            {
                return this.phone;
            }
            set
            {
                this.phone = value;
            }
        }
        public string Email
        {
            get
            {
                return this.email;
            }
            set
            {
                this.email = value;
            }
        }
        public decimal AmountPayable
        {
            get
            {
                return this.amountPayable;
            }
            set
            {
                this.amountPayable = value;
            }
        }

        public decimal SaleLimit
        {
            get
            {
                return this.saleLimit;
            }
            set
            {
                this.saleLimit = value;
            }
        }
        public void displayItem()
        {
            Console.WriteLine($"Customer's  ID : {this.customerID} ");
            Console.WriteLine($"Customer's  Name : {this.name}");
            Console.WriteLine($"Customer's  Address : {this.address} ");
            Console.WriteLine($"Customer's  Phone : {this.phone}");
            Console.WriteLine($"Customer's  Email : {this.email} ");
            Console.WriteLine($"Customer's  Amount Payable : {this.amountPayable} ");
            Console.WriteLine($"Customer's  Sale Limit : {this.saleLimit} ");
        }
    }
}
