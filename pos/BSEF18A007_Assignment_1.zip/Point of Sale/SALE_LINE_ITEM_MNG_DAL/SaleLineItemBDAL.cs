﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace SALE_LINE_ITEM_MNG_DAL
{
    public class SaleLineItemBDAL
    {
        internal void save(string saleLineItem, string fileName)
        {
            // Saving to the file
            string itemFile = Path.Combine(Environment.CurrentDirectory, fileName);
            StreamWriter sw = new StreamWriter(itemFile, append: true);
            sw.WriteLine(saleLineItem);
            sw.Close();
        }
        internal List<String> read(string fileName)
        {
            // reading from the file
            List<string> saleLineItemsList = new List<string>();
            string filePath = Path.Combine(Environment.CurrentDirectory, fileName);
            StreamReader sr = new StreamReader(filePath);
            string line = String.Empty;
            while ((line = sr.ReadLine()) != null)
            {

                saleLineItemsList.Add(line);

            }
            sr.Close();
            return saleLineItemsList;
        }

        internal void delete(string fileName)
        {
            // deleting the file
            if (File.Exists(fileName) == true)
            {
                File.Delete(fileName);
            }
            else
            {
                Console.WriteLine("File Not Exist");
            }
        }
    }
}
