﻿using SALE_LINE_ITEM_BO;
using System;
using System.Collections.Generic;
using System.Text;

namespace SALE_LINE_ITEM_MNG_DAL
{
    public class SaleLineItemDAL:SaleLineItemBDAL
    {
        public void saveSaleLineItem(SaleLineItemBO saleLineItemBO)
        {
            // Saving the sale line iTem in the form of string
            string saleLineItem = $"{saleLineItemBO.LineNo};{saleLineItemBO.OrderID};{saleLineItemBO.ItemID};{saleLineItemBO.Quantity};{saleLineItemBO.Amount}";
            save(saleLineItem, "SaleLineItems.txt");
        }
        public List<SaleLineItemBO> readSaleLineItems()
        {
            // Reading the sale line ITem from the File
            List<SaleLineItemBO> saleLineItemsList = new List<SaleLineItemBO>();
            List<String> items = new List<String>(read("SaleLineItems.txt"));
            foreach (string s in items)
            {
                string[] data = s.Split(";");
                SaleLineItemBO slbo = new SaleLineItemBO();
                slbo.LineNo = System.Convert.ToInt32(data[0]);
                slbo.OrderID = System.Convert.ToInt32(data[1]);
                slbo.ItemID = System.Convert.ToInt32(data[2]);
                slbo.Quantity = System.Convert.ToInt32(data[3]);
                slbo.Amount = System.Convert.ToDecimal(data[4]);
                saleLineItemsList.Add(slbo);
            }
            return saleLineItemsList;
        }

    }
}
