﻿using CUS_MNG_BL;
using CUS_MNG_BO;
using ITEM_MNG_BL;
using ITEM_MNG_BO;
using SALE_MNG_BO;
using SALE_MNG_DAL;
using System;
using System.Collections.Generic;
using System.Text;

namespace SALE_MNG_BL
{
    public class SaleBL
    {
        public int findCustomer(int id)
        {
            // It will return -1 if the customer is not there other it will return the customer ID
            CustomerBL cbl = new CustomerBL();
            
            int index = cbl.find(id).CustomerID;
            if(index==default(int))
            {
                index = -1;
            }
            
            return index;
        }
        public bool isStockAvailable(int itemID, int quantity)
        {
            // in order to check wether the stock is there or not

            bool stock = true;
            ItemBL itemBL = new ItemBL();
            ItemBO item = itemBL.find(itemID);
            if(item.Quantity<quantity)
            {
                stock = false;
            }
            return stock;
        }
        public void saveSale(SaleBO sbo,decimal totalAmount)
        {
            // Saving the sale ad updating the customer amount payable as well
            CustomerBL customerBL = new CustomerBL();
            CustomerBO customerBO = customerBL.find(sbo.CustomerID);
            customerBO.AmountPayable = totalAmount;
            customerBL.updateCustomer(customerBO.CustomerID,customerBO);
            SaleDAL saleDAL = new SaleDAL();
            saleDAL.saveSale(sbo);

        }
        public bool isLimitExceded(SaleBO sale,decimal amount)
        {
            // Chech k for the Sale limit exceded
            bool limit = false;
            CustomerBL cBL = new CustomerBL();
            CustomerBO cBO = cBL.find(sale.CustomerID);
            if(cBO.SaleLimit<amount)
            {
                limit = true;
            }
            return limit;
        }
        public List<SaleBO> readSale()
        {
            // to get sales stored in the file
            List<SaleBO> saleList = new List<SaleBO>();
            SaleDAL saleDAL = new SaleDAL();
            saleList=saleDAL.readSales();
            return saleList;
        }
        public SaleBO getSaleBO(int orderID)
        {
            // To get the sale BO
            SaleBO saleBO = new SaleBO();
            List<SaleBO> saleBOs = readSale();
            foreach(SaleBO sBO in saleBOs)
            {
                if(sBO.OrderID==orderID)
                {
                    return sBO;
                }
            }
            return saleBO;
        }
    }
}
