﻿using CUS_MNG_BL;
using CUS_MNG_BO;
using ITEM_MNG_BL;
using ITEM_MNG_BO;
using SALE_LINE_ITEM_BL;
using SALE_LINE_ITEM_BO;
using SALE_MNG_BL;
using SALE_MNG_BO;
using System;
using System.Collections.Generic;
using System.Text;

namespace REPORT_MNG_BL
{
    public class ReportBL
    {
        public List<ItemBO> getItems(int start,int end)
        {
            // To get the ITems on the basis of the IDs range
            List < ItemBO > reqItemBOs= new List<ItemBO>();
            ItemBL itemBL = new ItemBL();
            List<ItemBO> items=itemBL.readItems();
            foreach(ItemBO itemBO in items)
            {
                if(start!=default(int ) && end!=default(int))
                {
                    if (itemBO.ItemID >= start && itemBO.ItemID <= end)
                    {
                        reqItemBOs.Add(itemBO);
                    }
                }
                else if(start==default(int) && end!=default(int))
                {
                    if(itemBO.ItemID<=end)
                    {
                        reqItemBOs.Add(itemBO);
                    }
                }
                else if(start != default(int) && end == default(int))
                {
                    if (itemBO.ItemID >= start)
                    {
                        reqItemBOs.Add(itemBO);
                    }
                }
            }
            
            return reqItemBOs;
        }

        public CustomerBO getCustomer(int iD)
        {
            CustomerBL customerBL = new CustomerBL();
            return customerBL.find(iD);
        }

        public List<ItemBO> getItemBOs(DateTime dateTime)
        {
            List<ItemBO> itemBOs = new List<ItemBO>();

            return itemBOs;
        }
        public List<ItemBO> getSalesRepotedItems(DateTime start, DateTime end)
        {

            List<SaleBO> saleBOs = GetSaleBOsBasedOnDate(start, end);
            SaleLineItemBL saleLineItemBL = new SaleLineItemBL();
            List<SaleLineItemBO> saleLineItems = saleLineItemBL.readSaleLineItem();
            List<SaleLineItemBO> selectedSaleLineItems = new List<SaleLineItemBO>();
            ItemBL itemBL = new ItemBL();
            List<ItemBO> items = itemBL.readItems();
            List<ItemBO> reqItems = new List<ItemBO>();
           
            // THis is done to filter the sale line items according to date range
            foreach(SaleBO saleBO in saleBOs)
            {
                foreach(SaleLineItemBO saleLineItem in saleLineItems)
                {
                    if(saleLineItem.OrderID==saleBO.OrderID)
                    {
                        selectedSaleLineItems.Add(saleLineItem);
                    }
                }
            }

            // this is to calculate the actual quatity sold and price to which it was sold
            foreach(ItemBO item in items)
            {
                ItemBO itemBO = new ItemBO();
                int quantity = 0;
                foreach(SaleLineItemBO saleLineItem in selectedSaleLineItems)
                {
                    if(saleLineItem.ItemID==item.ItemID)
                    {
                        quantity = quantity + saleLineItem.Quantity;
                    }
                }
                if(quantity!=0)
                {
                    itemBO.ItemID = item.ItemID;
                    itemBO.Description = item.Description;
                    itemBO.Quantity = quantity;
                    itemBO.Price = item.Price * quantity;
                    reqItems.Add(itemBO);
                }
            }


            return reqItems;
        }
        public List<SaleBO> GetSaleBOsBasedOnDate(DateTime start,DateTime end)
        {
            // Getting the salesBOs report on the basis of the date mentioned
            List<SaleBO> saleBOs = new List<SaleBO>();
            SaleBL saleBL = new SaleBL();
            List<SaleBO> oldSales=saleBL.readSale();
            if(start!=default(DateTime)&& end!=default(DateTime))
            {
                foreach(SaleBO sale in oldSales)
                {
                    if(sale.SaleDate>=start && sale.SaleDate<=end)
                    {
                        saleBOs.Add(sale);
                    }
                }
            }
            else if(start!=default(DateTime))
            {
                foreach (SaleBO sale in oldSales)
                {
                    if (sale.SaleDate == start)
                    {
                        saleBOs.Add(sale);
                    }
                }
            }
            else if(end!=default(DateTime))
            {
                foreach (SaleBO sale in oldSales)
                {
                    if (sale.SaleDate == end)
                    {
                        saleBOs.Add(sale);
                    }
                }
            }
            return saleBOs;
        }
    }
}
