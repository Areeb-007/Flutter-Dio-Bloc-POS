﻿using POS_VIEW;
using System;

namespace Point_of_Sale
{
    class Program
    {
        static void Main(string[] args)
        {
            // This is the object for Point Of sale System. So that we can execute the system
            PosView pos = new PosView();
            pos.displayMainMenu();
        }
    }
}
