﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITEM_MNG_BO
{
    public class ItemBO
    {
        private int itemID;
        private string description;
        private decimal price;
        private int quantity;
        private DateTime creationDate;

        public int ItemID
        {
            get
            {
                return this.itemID;
            }
            set
            {
                this.itemID = value;
            }
        }


        public string Description
        {
            get
            {
                return this.description;
            }
            set
            {
                this.description = value;
            }
        }
        public decimal Price
        {
            get
            {
                return this.price;
            }
            set
            {
                this.price = value;
            }
        }
        public int Quantity
        {
            get
            {
                return this.quantity;
            }
            set
            {
                this.quantity = value;
            }

        }
        public DateTime CreationDate
        {
            get
            {
                return this.creationDate;
            }
            set
            {
                this.creationDate = value;
            }
        }
        public void displayItem()
        {
            Console.WriteLine($"Item's ID : {this.itemID} ");
            Console.WriteLine($"Item's Description : {this.description}");
            Console.WriteLine($"Item's Price : {this.price} ");
            Console.WriteLine($"Item's Quantity : {this.quantity}");
            Console.WriteLine($"Item's Creation Date : {this.creationDate} ");
        }
    }
}
