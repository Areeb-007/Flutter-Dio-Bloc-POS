﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SALE_MNG_BO
{
    public class SaleBO
    {
        int orderID;
        int customerID;
        DateTime date;
        bool status;

        public int OrderID
        {
            get
            {
                return this.orderID;
            }
            set
            {
                this.orderID = value;
            }
        }

        public int CustomerID
        {
            get
            {
                return this.customerID;
            }
            set
            {
                this.customerID = value;
            }
        }
        public DateTime SaleDate
        {
            get
            {
                return this.date;
            }
            set
            {
                this.date = value;
            }
        }

        public bool Status
        {
            get
            {
                return this.status;
            }
            set
            {
                this.status = value;
            }
        }
    }
}
