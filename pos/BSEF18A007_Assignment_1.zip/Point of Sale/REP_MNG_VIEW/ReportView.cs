﻿using CUS_MNG_BO;
using ITEM_MNG_BO;
using PAYMENT_MNG_BL;
using REPORT_MNG_BL;
using SALE_LINE_ITEM_BL;
using SALE_MNG_BO;
using System;
using System.Collections.Generic;
using System.Text;

namespace REP_MNG_VIEW
{
    public class ReportView
    {
        public void displayReportsMenu()
        {
            int choice = 0;
            do
            {
                Console.WriteLine("<----------------- Reports Menu ----------------->");
                Console.WriteLine("1- Stock in Hand.");
                Console.WriteLine("2- Customer Balance.");
                Console.WriteLine("3- Sales Report (by Date).");
                Console.WriteLine("4- Outstanding Sales (by Date).");
                Console.WriteLine("5- Back to Main Menu.");
                Console.WriteLine("Press 1 to 5 to Select an option : ");
                try
                {
                    choice = System.Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                switch (choice)
                {
                    case 1:
                        getInputForStockInHand();
                        break;
                    case 2:
                        getInputForCustomerBalance();
                        break;
                    case 3:
                        getInputForSalesReport();
                        break;
                    case 4:
                        getInputForOutStandingSales();
                        break;
                    case 5:
                        break;
                    default:
                        Console.WriteLine("Choice not available!!");
                        break;
                }
            } while (choice != 5);
        }

        public void getInputForStockInHand()
        {
            int startingItemID = default(int);
            int endingItemID = default(int);
            Console.WriteLine("Enter Starting Item ID : ");
            try
            {
                startingItemID = System.Convert.ToInt32(Console.ReadLine());
            }
            catch(Exception ex)
            {

            }
            Console.WriteLine("Enter Ending Item ID : ");
            try
            {
                endingItemID = System.Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {

            }
            ReportBL reportBL = new ReportBL();
            List<ItemBO> itemsList = reportBL.getItems(startingItemID, endingItemID);
            Console.WriteLine("-------------------------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("{0,-15} {1,-37} {2,-25} {3,-21} ", "Item ID", "Description", "Price", "Quantity in Hand");
            Console.WriteLine("-------------------------------------------------------------------------------------------------------------------------------------------");
            foreach (ItemBO ibo in itemsList)
            {
                Console.WriteLine("{0,-15} {1,-37} {2,10:C} {3,30:N0} ", ibo.ItemID, ibo.Description, ibo.Price, ibo.Quantity);
            }
            Console.WriteLine("-------------------------------------------------------------------------------------------------------------------------------------------");
        }

        public void getInputForCustomerBalance()
        {
            Console.WriteLine("Please Enter Customer ID : ");
            int customerID = default(int);
            try
            {
                customerID = System.Convert.ToInt32(Console.ReadLine());
            }
            catch(Exception ex)
            {
                Console.WriteLine("ID Format is Invalid.");
            }
            ReportBL reportBL = new ReportBL();
            CustomerBO customer=reportBL.getCustomer(customerID);
            if(customer.CustomerID==default(int))
            {
                Console.WriteLine("Customer Does not Exist");
            }
            else
            {
                Console.WriteLine($"Customer Name: {customer.Name}");
                Console.WriteLine($"Address: {customer.Address}");
                Console.WriteLine($"Phone: {customer.Phone}");
                Console.WriteLine($"Email: {customer.Email}");
                Console.WriteLine("Balance: {0:C}", customer.AmountPayable);
            }
        }
        public void getInputForSalesReport()
        {
            Console.WriteLine("Enter Starting Date : ");
            DateTime startDate = default(DateTime);
            try
            {
                startDate = System.Convert.ToDateTime(Console.ReadLine());
            }
            catch(Exception ex)
            {

            }
            Console.WriteLine("Enter Ending Date : ");
            DateTime endDate = default(DateTime);
            try
            {
                endDate = System.Convert.ToDateTime(Console.ReadLine());
            }
            catch (Exception ex)
            {

            }
            ReportBL reportBL = new ReportBL();
            List<ItemBO> items = reportBL.getSalesRepotedItems(startDate,endDate);
            Console.WriteLine("---------------------------------------------------------------------------------------------------");
            Console.WriteLine("{0,-20}{1,-30}{2,-30}{3}", "Item ID", "Description", "Quantity Sold", "Amount");
            Console.WriteLine("---------------------------------------------------------------------------------------------------");
            foreach(ItemBO item in items)
            {
                Console.WriteLine("{0,-20}{1,-30}{2,12:N0}{3,24:C}", item.ItemID, item.Description, item.Quantity, item.Price);
            }
            Console.WriteLine("---------------------------------------------------------------------------------------------------");
        }
        public void getInputForOutStandingSales()
        {
            Console.WriteLine("Enter Starting Date : ");
            DateTime startDate = default(DateTime);
            try
            {
                startDate = System.Convert.ToDateTime(Console.ReadLine());
            }
            catch (Exception ex)
            {

            }
            Console.WriteLine("Enter Ending Date : ");
            DateTime endDate = default(DateTime);
            try
            {
                endDate = System.Convert.ToDateTime(Console.ReadLine());
            }
            catch (Exception ex)
            {

            }
            // A fuction that returns the required Sales
            ReportBL reportBL = new ReportBL();
            List<SaleBO> saleBOs = reportBL.GetSaleBOsBasedOnDate(startDate, endDate);
            Console.WriteLine("---------------------------------------------------------------------------------------------------");
            Console.WriteLine("{0,-20}{1,-30}{2,-30}{3}", "Sale ID", "Customer Name", "Total Amount", "Remaining Amount");
            Console.WriteLine("---------------------------------------------------------------------------------------------------");
            foreach (SaleBO sale in saleBOs)
            {
                PaymentBL paymentBL = new PaymentBL();
                CustomerBO customer = paymentBL.getCustomer(sale.OrderID);
                SaleLineItemBL saleLineItemBL = new SaleLineItemBL();
                decimal totalAmount = saleLineItemBL.calculateTotalAmount(saleLineItemBL.getSaleLineItemsForOrderID(sale.OrderID));
                Console.WriteLine("{0,-20}{1,-30}{2,12:C}{3,34:C}",sale.OrderID , customer.Name, totalAmount, customer.AmountPayable);
            }
            Console.WriteLine("---------------------------------------------------------------------------------------------------");
        }
    }
}
