﻿using CUS_MNG_VIEW;
using ITEM_MNG_VIEW;
using PAYMENT_MNG_VIEW;
using REP_MNG_VIEW;
using SALE_MNG_VIEW_2;
using System;
using System.Collections.Generic;
using System.Text;

namespace POS_VIEW
{
    public class PosView
    {
        public void displayMainMenu()
        {
            int choice = 0;
            do
            {
                Console.WriteLine("<----------------- POS ----------------->");
                Console.WriteLine("1- Manage Items.");
                Console.WriteLine("2- Manage Customers.");
                Console.WriteLine("3- Make New Sale.");
                Console.WriteLine("4- Make Payment.");
                Console.WriteLine("5- Print Reports.");
                Console.WriteLine("6- Exit.");
                Console.WriteLine("Press 1 to 5 to Select an option : ");
                try
                {
                    choice = System.Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                switch (choice)
                {
                    case 1:
                        ItemView itemsView = new ItemView();
                        itemsView.displayItemsMenu();
                        break;
                    case 2:
                        CustomerView custView = new CustomerView();
                        custView.displayCustomersMenu();
                        break;
                    case 3:
                        SaleView saleView = new SaleView();
                        saleView.displaySaleMenu();
                        break;
                    case 4:
                        PaymentView paymentView = new PaymentView();
                        paymentView.getInputForPayment();
                        break;
                    case 5:
                        ReportView repView = new ReportView();
                        repView.displayReportsMenu();
                        break;
                    case 6:
                        Console.WriteLine("Thanks for using our services.");
                        break;
                    default:
                        Console.WriteLine("Choice not available!!");
                        break;
                }
            } while (choice != 6);
        }
    }
}
