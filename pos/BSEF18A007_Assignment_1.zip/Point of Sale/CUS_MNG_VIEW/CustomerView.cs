﻿using CUS_MNG_BL;
using CUS_MNG_BO;
using System;
using System.Collections.Generic;
using System.Text;

namespace CUS_MNG_VIEW
{
    public class CustomerView
    {
        public void displayCustomersMenu()
        {
            int choice = 0;
            do
            {
                Console.WriteLine("<----------------- Customers Menu ----------------->");
                Console.WriteLine("1- Add New Customer.");
                Console.WriteLine("2- Update Customer details.");
                Console.WriteLine("3- Find Customer.");
                Console.WriteLine("4- Remove Existing Customer.");
                Console.WriteLine("5- Back to Main Menu.");
                Console.WriteLine("Press 1 to 5 to Select an option : ");
                try
                {
                    choice = System.Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                switch (choice)
                {
                    case 1:
                        getInputForCustomerAddition();
                        break;
                    case 2:
                        getInputToUpdateCustomer();
                        break;
                    case 3:
                        findCustomer();
                        break;
                    case 4:
                        getInputForDeleting();
                        break;
                    case 5:
                        break;
                    default:
                        Console.WriteLine("Choice not available!!");
                        break;
                }
            } while (choice != 5);
        }
        public void getInputForCustomerAddition()
        {
            // Getting Input for the Customer's Name
            Console.WriteLine("Enter Customers Name :");
            string name = Console.ReadLine();

            // Getting Input for the Customer's Address
            Console.WriteLine("Enter Customer's Address : ");
            string address = Console.ReadLine();

            //Getting Input for the Customer's Phone
            Console.WriteLine("Enter Customer's Phone : ");
            string  phone = Console.ReadLine();

            //Getting Input for the Customer's Email
            Console.WriteLine("Enter Customer's Email : ");
            string email = Console.ReadLine();

            //Getting Input for the Customer's Amount Payable
            Console.WriteLine("Enter Customer's Amount Payable : ");
            decimal amountPayable = System.Convert.ToDecimal(Console.ReadLine());

            //Getting Input for the Customer's Sale Limit
            Console.WriteLine("Enter Customer's Sale Limit : ");
            decimal saleLimit = System.Convert.ToDecimal(Console.ReadLine());

            // Customer Object
            CustomerBO cbo = new CustomerBO();

            cbo.Name = name;
            cbo.Address = address;
            cbo.Phone = phone;
            cbo.Email = email;
            cbo.AmountPayable = amountPayable;
            cbo.SaleLimit = saleLimit;

            //ItemBL ibl = new ItemBL();
            //ibl.saveItem(i);

            CustomerBL cbl = new CustomerBL();
            cbl.saveCustomer(cbo);

        }
        public void getInputToUpdateCustomer()
        {
            //Getting input of Customer Id to update its Content
            Console.WriteLine("Please Enter the Customer Id you want to Update.  ");
            int idForCustomer = System.Convert.ToInt32(Console.ReadLine());
            CustomerBL cbl = new CustomerBL();
            CustomerBO index = cbl.find(idForCustomer);
            if (index.CustomerID == default(int))
            {
                Console.WriteLine("Item not found.");
            }
            else
            {
                CustomerBO bo = new CustomerBO();
                Console.WriteLine("----------------------------------------------------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine("{0,-12} {1,-27} {2,-39} {3,-15} {4,-27} {5,-15} {6}", "Customer ID", "Name", "Address", "Phone", "Email","Amount Payable","Sale Limit");
                Console.WriteLine("----------------------------------------------------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine("{0,-12} {1,-27} {2,-39} {3,-15} {4,-27} {5,-15:N0} {6:N0}", index.CustomerID, index.Name, index.Address,index.Phone ,index.Email, index.AmountPayable,index.SaleLimit);

                Console.WriteLine("Enter the data to update in the field, if not necessary then leave it empty.");
                // Getting Input for the Customer's Name
                Console.WriteLine("Enter Customer's Name :");
                string name = Console.ReadLine();
                if (name.Equals(String.Empty))
                {
                    name = default(string);
                }

                // Getting Input for the Customer's Address
                Console.WriteLine("Enter Customer's Address : ");
                string address = Console.ReadLine();
                if (address.Equals(String.Empty))
                {
                    address = default(string);
                }

                // Getting Input for the Customer's Phone
                Console.WriteLine("Enter Customer's Phone :");
                string phone = Console.ReadLine();
                if (phone.Equals(String.Empty))
                {
                    phone = default(string);
                }

                // Getting Input for the Customer's Email
                Console.WriteLine("Enter Customer's Email :");
                string email = Console.ReadLine();
                if (email.Equals(String.Empty))
                {
                    email = default(string);
                }

                // Getting Input for the Customer's Amount Payable
                Console.WriteLine("Enter Customer's Amount Payable :");
                decimal amountPayable =default(decimal);
                try 
                {
                    amountPayable = System.Convert.ToDecimal(Console.ReadLine()) ;
                }
                catch(Exception ex)
                {

                }

                // Getting Input for the Customer's Sale Limit
                Console.WriteLine("Enter Customer's Sale Limit :");
                decimal saleLimit = default(decimal);
                try
                {
                    saleLimit = System.Convert.ToDecimal(Console.ReadLine());
                }
                catch (Exception ex)
                {

                }

                // Customer Object
                CustomerBO cbo = new CustomerBO();

                cbo.Name = name;
                cbo.Address = address;
                cbo.Phone = phone;
                cbo.Email = email;
                cbo.AmountPayable = amountPayable;
                cbo.SaleLimit = saleLimit;

                cbl.updateCustomer(index.CustomerID, cbo);

            }
        }
        public void getInputForDeleting()
        {
            Console.WriteLine("Please enter the Customer Id you want to remove.");
            int id = default(int);
            try
            {
                id = System.Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            CustomerBL cbl = new CustomerBL();
            CustomerBO index = cbl.find(id);

            //If the user leaves it blanks or enter invalid input then it will not be stored and remain default
            if (index.CustomerID == default(int))
            {
                Console.WriteLine("No Such Item Exist");
            }
            else
            {
                cbl.deleteItem(index.CustomerID);
            }
        }
        public void findCustomer()
        {
            Console.WriteLine("Please specify atleast one of the following to find the Customer. Leave all fields blank to return to Customer's Menu:");
            
            // Getting Iput for Customer's ID
            Console.WriteLine("Enter Customer's ID : ");
            int id = default(int);
            try
            {
                id = System.Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {

            }

            // Getting Input for the Customer's Name
            Console.WriteLine("Enter Customer's Name :");
            string name = Console.ReadLine();
            if (name.Equals(String.Empty))
            {
                name = default(string);
            }

            // Getting Input for the Customer's Address
            Console.WriteLine("Enter Customer's Address : ");
            string address = Console.ReadLine();
            if (address.Equals(String.Empty))
            {
                address = default(string);
            }

            // Getting Input for the Customer's Phone
            Console.WriteLine("Enter Customer's Phone :");
            string phone = Console.ReadLine();
            if (phone.Equals(String.Empty))
            {
                phone = default(string);
            }

            // Getting Input for the Customer's Email
            Console.WriteLine("Enter Customer's Email :");
            string email = Console.ReadLine();
            if (email.Equals(String.Empty))
            {
                email = default(string);
            }

            // Getting Input for the Customer's Amount Payable
            Console.WriteLine("Enter Customer's Amount Payable :");
            decimal amountPayable = default(decimal);
            try
            {
                amountPayable = System.Convert.ToDecimal(Console.ReadLine());
            }
            catch (Exception ex)
            {

            }

            // Getting Input for the Customer's Sale Limit
            Console.WriteLine("Enter Customer's Sale Limit :");
            decimal saleLimit = default(decimal);
            try
            {
                saleLimit = System.Convert.ToDecimal(Console.ReadLine());
            }
            catch (Exception ex)
            {

            }

            // Customer Object
            CustomerBO cbo = new CustomerBO();

            cbo.CustomerID = id;
            cbo.Name = name;
            cbo.Address = address;
            cbo.Phone = phone;
            cbo.Email = email;
            cbo.AmountPayable = amountPayable;
            cbo.SaleLimit = saleLimit;

            CustomerBL itemBL = new CustomerBL();

            List<CustomerBO> itemsFound = itemBL.findItems(cbo);
            if (itemsFound.Count == 0)
            {
                Console.WriteLine("No Such Item Exist.");
            }
            else
            {
                Console.WriteLine("----------------------------------------------------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine("{0,-12} {1,-27} {2,-39} {3,-15} {4,-27} {5,-15} {6}", "Customer ID", "Name", "Address", "Phone", "Email", "Amount Payable", "Sale Limit");
                Console.WriteLine("----------------------------------------------------------------------------------------------------------------------------------------------------------------");
                foreach (CustomerBO cbo2 in itemsFound)
                {
                    Console.WriteLine("{0,-12} {1,-27} {2,-39} {3,-15} {4,-27} {5,-15:N0} {6:N0}", cbo2.CustomerID, cbo2.Name, cbo2.Address, cbo2.Phone, cbo2.Email, cbo2.AmountPayable, cbo2.SaleLimit);
                }
                Console.WriteLine("----------------------------------------------------------------------------------------------------------------------------------------------------------------");
            }
        }
    }
}
