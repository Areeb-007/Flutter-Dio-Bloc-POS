﻿using CUS_MNG_BL;
using CUS_MNG_BO;
using ITEM_MNG_BL;
using ITEM_MNG_BO;
using Order_KEY_GEN;
using SALE_LINE_ITEM_BL;
using SALE_LINE_ITEM_BO;
using SALE_LINE_KEY_GEN;
using SALE_MNG_BL;
using SALE_MNG_BO;
using System;
using System.Collections.Generic;
using System.Text;

namespace SALE_MNG_VIEW_2
{
    public class SaleView
    {
        public void displaySaleMenu()
        {
            List<SaleLineItemBO> saleLineItems = new List<SaleLineItemBO>();
            OrderKey oKey = new OrderKey();
            SaleBO sbo = new SaleBO();
            // System Generated Sale iD

            sbo.OrderID = oKey.generateKey();

            // System Generated Sale Date
            sbo.SaleDate = DateTime.Now.Date;
            Console.WriteLine($"Sales ID : {sbo.OrderID}");
            Console.WriteLine($"Sales Date : {sbo.SaleDate.ToString("dd/MM/yyyy")}");
            Console.WriteLine("Enter Customer ID : ");

            // Getting input for the customer iD
            int id = default(int);
            try
            {
                id =System.Convert.ToInt32( Console.ReadLine());
            }
            catch(Exception ex)
            {

            }
            SaleBL sbl = new SaleBL();

            // Find the customer on the basis of Customer ID Entered
            int index = sbl.findCustomer(id);
            if(index==-1)
            {
                Console.WriteLine("No Such Customer Exist.");
            }
            else
            {
                sbo.CustomerID = index;
                int choice = 0;
                List<SaleLineItemBO> lineItems = new List<SaleLineItemBO>();
                do
                {
                    Console.WriteLine("Press 1 to Enter New Item.");
                    Console.WriteLine("Press 2 to End Sale.");
                    Console.WriteLine("Press 3 to Remove an Existing Item.");
                    Console.WriteLine("Press 4 to Cancel Sale");
                    choice = System.Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            getInputForNewItem(ref saleLineItems,sbo);
                            break;
                        case 2:
                            sbo.Status = true;
                            endSale(saleLineItems, sbo);
                            break;
                        case 3:
                            getInputForRemovingItem(ref saleLineItems);
                            break;
                        case 4:
                            break;
                      
                    }

                } while (choice != 4 && choice != 2);
            }

        }

        public void getInputForRemovingItem(ref List<SaleLineItemBO> saleLineItems)
        {
            Console.WriteLine("Please Enter the Iem ID you want to Remove.");
            int id = default(int);
            try
            {
                id=System.Convert.ToInt32(Console.ReadLine());
            }
            catch(Exception ex)
            {

            }
            if(id==default(int))
            {
                Console.WriteLine("Item is not in the Sale.");
            }
            else
            {
                SaleLineItemBL saleLineItemBL = new SaleLineItemBL();
                saleLineItems = saleLineItemBL.removeItem(saleLineItems,id);
            }
        }
        public void getInputForNewItem(ref List<SaleLineItemBO> saleLineItems,SaleBO sBo)
        {
            Console.WriteLine("Enter Item ID : ");
            int itemID = default(int);
            try
            {
                itemID = System.Convert.ToInt32(Console.ReadLine());
            }
            catch(Exception ex)
            {

            }
            if(itemID==default(int))
            {
                Console.WriteLine("Invalid ID Format.");
            }
            else
            {
                ItemBL iBL = new ItemBL();
                // finding item on the basis of the Id

                ItemBO iBO = iBL.find(itemID);
                if(iBO.ItemID!=itemID)
                {
                    Console.WriteLine("Item Does Not Exist");
                }
                else
                {
                    //Displaying the information of Item found.
                    Console.WriteLine($"Item's Description : {iBO.Description}");
                    Console.WriteLine($"Price : {iBO.Price}");
                    Console.WriteLine("Quantity : ");
                    int quantity = default(int);
                    try
                    {
                        quantity = System.Convert.ToInt32(Console.ReadLine());
                    }
                    catch(Exception ex)
                    {

                    }
                    if(quantity<0 || quantity==default(int))
                    {
                        Console.WriteLine("Invalid Quantity Entered.");
                    }
                    else
                    {
                        //Check for the stock 
                        SaleBL saleBL = new SaleBL();
                        if(saleBL.isStockAvailable(itemID,quantity))
                        {
                            SaleLineItemBO saleLineItemBO = new SaleLineItemBO();
                            SaleLineKey saleLineKey = new SaleLineKey();
                            saleLineItemBO.LineNo = saleLineKey.generateKey();
                            saleLineItemBO.OrderID = sBo.OrderID;
                            saleLineItemBO.ItemID = iBO.ItemID;
                            saleLineItemBO.Quantity = quantity;
                            saleLineItemBO.Amount = quantity * (iBO.Price);
                            saleLineItems.Add(saleLineItemBO);
                        }
                        else
                        {
                            Console.WriteLine("Stock not Available.");
                        }

                        
                    }
                }
            }

        }
        public void endSale(List<SaleLineItemBO> saleLineItemBOs,SaleBO saleBO)
        {
            decimal totalAmount = 0;
            SaleLineItemBL saleLineItemBL = new SaleLineItemBL();
            SaleBL saleBL = new SaleBL();

            // To calculate the total amount of the sale
            totalAmount = saleLineItemBL.calculateTotalAmount(saleLineItemBOs);
            // To chech wether customers sales limit exceded or not

            if(saleBL.isLimitExceded(saleBO,totalAmount))
            {
                Console.WriteLine("Sale Limit Exceded.");
            }
            else
            {
                saleBL.saveSale(saleBO, totalAmount);
                foreach (SaleLineItemBO sbo in saleLineItemBOs)
                {
                    saleLineItemBL.saveSaleLineItem(sbo);
                }
                CustomerBL customerBL = new CustomerBL();
                CustomerBO customerBO = customerBL.find(saleBO.CustomerID);
                Console.WriteLine("Sale ID:  {0,-65} Customer ID: {1}",saleBO.OrderID,saleBO.CustomerID);
                Console.WriteLine("Sale Date:  {0,-63} Name: {1}", saleBO.SaleDate.ToString("dd/MM/yyyy"),customerBO.Name);
                Console.WriteLine("----------------------------------------------------------------------------------------------");
                Console.WriteLine("{0,-20}{1,-30}{2,-30}{3}", "Item Id", "Description", "Quantity", "Amount");
                Console.WriteLine("----------------------------------------------------------------------------------------------");
                foreach(SaleLineItemBO saleLineItemBO in saleLineItemBOs)
                {
                    ItemBL itemBL = new ItemBL();
                    ItemBO itemBO = itemBL.find(saleLineItemBO.ItemID);
                    Console.WriteLine("{0,-20}{1,-30}{2,-30}{3}",saleLineItemBO.ItemID, itemBO.Description, saleLineItemBO.Quantity, saleLineItemBO.Amount);
                }
                Console.WriteLine("----------------------------------------------------------------------------------------------");
                Console.WriteLine("{0,79} {1:C}","Total Sales: ",totalAmount);
                Console.WriteLine("Press Any Key to Continue.");
                Console.ReadLine();
            }
        }
    }
}
