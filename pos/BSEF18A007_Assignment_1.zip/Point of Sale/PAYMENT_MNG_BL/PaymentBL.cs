﻿using CUS_MNG_BL;
using CUS_MNG_BO;
using SALE_LINE_ITEM_BL;
using SALE_LINE_ITEM_BO;
using SALE_MNG_BL;
using SALE_MNG_BO;
using System;
using System.Collections.Generic;
using System.Text;

namespace PAYMENT_MNG_BL
{
    public class PaymentBL
    {
        public SaleBO getSale(int saleID)
        {
            SaleBO saleBO = new SaleBO();
            SaleBL saleBL = new SaleBL();
            saleBO = saleBL.getSaleBO(saleID);
            return saleBO;
        }
        public static bool isSaleIDExist(int saleID)
        {
            SaleLineItemBL saleLineItemBL = new SaleLineItemBL();
           return saleLineItemBL.isSaleIdExist(saleID);
        }
        public CustomerBO getCustomer(int saleID)
        {
            CustomerBL customerBL = new CustomerBL();
            SaleBL saleBL = new SaleBL();
            SaleBO saleBO = saleBL.getSaleBO(saleID);
            return customerBL.find(saleBO.CustomerID);
        }
        public static List<SaleLineItemBO> getSaleLineItems(int saleId)
        {
            // To get the sale line items on the basis of the Sale iD
            SaleLineItemBL saleLineItemBL = new SaleLineItemBL();
            List<SaleLineItemBO> newSaleLineItemBOs = new List<SaleLineItemBO>();
            List<SaleLineItemBO> saleLineItems = saleLineItemBL.readSaleLineItem();
            foreach(SaleLineItemBO saleLineItemBO in saleLineItems)
            {
                if(saleLineItemBO.OrderID==saleId)
                {
                    newSaleLineItemBOs.Add(saleLineItemBO);
                }
            }
            return newSaleLineItemBOs;
        }
    }
}
