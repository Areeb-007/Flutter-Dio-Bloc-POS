﻿using CUS_MNG_BL;
using CUS_MNG_BO;
using PAYMENT_MNG_BL;
using SALE_LINE_ITEM_BL;
using System;
using System.Collections.Generic;
using System.Text;

namespace PAYMENT_MNG_VIEW
{
    public class PaymentView
    {
        public void getInputForPayment()
        {
            Console.WriteLine("Enter a valid Sale ID : ");
            int saleID = default(int);
            try
            {
                saleID = System.Convert.ToInt32(Console.ReadLine());
            }
            catch(Exception ex)
            {
                
            }
            if (saleID == default(int))
            {
                Console.WriteLine("Invalid Format for the Sale ID.");
            }
            else
            {
                //To check wether the sale exist or not
                if(PaymentBL.isSaleIDExist(saleID)==false)
                {
                    Console.WriteLine("Sale Id does not exist.");
                }
                else
                {
                    // Finding the customer on the basis of the Sale ID entered
                    PaymentBL paymentBL = new PaymentBL();
                    CustomerBO customer = paymentBL.getCustomer(saleID);
                    Console.WriteLine($"Customer Name : {customer.Name}");

                    SaleLineItemBL saleLineItemBL = new SaleLineItemBL();

                    decimal totalAmount = saleLineItemBL.calculateTotalAmount(saleLineItemBL.getSaleLineItemsForOrderID(saleID));
                    Console.WriteLine("Total Sales Amount : {0:N0}", totalAmount);
                    
                    
                    //Calculating the Paid Amount 
                    Console.WriteLine("Amount Paid : {0:N0}", totalAmount - customer.AmountPayable);
                    Console.WriteLine("Remaing Amount : {0:N0}", customer.AmountPayable);

                    Console.WriteLine("Amount to be paid : ");
                    decimal amountToBePaid = default(decimal);
                    try
                    {
                        amountToBePaid=System.Convert.ToDecimal( Console.ReadLine());
                    }
                    catch(Exception ex)
                    {

                    }
                    if(amountToBePaid<0 || amountToBePaid>customer.AmountPayable || amountToBePaid==default(decimal))
                    {
                        Console.WriteLine("Amount is not Valid");
                    }
                    else
                    {
                        // Updating the customer for amount enterd
                        customer.AmountPayable = customer.AmountPayable - amountToBePaid;
                        CustomerBL customerBL = new CustomerBL();
                        customerBL.updateCustomer(customer.CustomerID, customer);
                    }
                }
            }
        }
    }
}
