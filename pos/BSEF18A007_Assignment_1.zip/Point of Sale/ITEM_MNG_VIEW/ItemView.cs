﻿using ITEM_MNG_BL;
using ITEM_MNG_BO;
using System;
using System.Collections.Generic;

namespace ITEM_MNG_VIEW
{
    public class ItemView
    {
        public void displayItemsMenu()
        {
            int choice = 0;
            do
            {
                Console.WriteLine("<----------------- Items Menu ----------------->");
                Console.WriteLine("1- Add New Item.");
                Console.WriteLine("2- Update Item details.");
                Console.WriteLine("3- Find Items.");
                Console.WriteLine("4- Remove Existing Item.");
                Console.WriteLine("5- Back to Main Menu.");
                Console.WriteLine("Press 1 to 5 to Select an option : ");
                try
                {
                    choice = System.Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                switch (choice)
                {
                    case 1:
                        getInputForItem();
                        break;
                    case 2:
                        getInputToUpdateItem();
                        break;
                    case 3:
                        findItem();
                        break;
                    case 4:
                        getInputForDeleting();
                        break;
                    case 5:
                        break;
                    default:
                        Console.WriteLine("Choice not available!!");
                        break;
                }
            } while (choice != 5);
        }
        public void getInputForItem()
        {
            // Getting Input for the Item's Description
            Console.WriteLine("Enter Item's Description :");
            string des = Console.ReadLine();

            // Getting Input for the Item's Price
            Console.WriteLine("Enter Item's Price : ");
            decimal prc = System.Convert.ToDecimal(Console.ReadLine());

            //Getting Input for the Item's Quantity
            Console.WriteLine("Enter Item's Quantity : ");
            int quan = System.Convert.ToInt32(Console.ReadLine());

            // Item Object
            ItemBO i = new ItemBO();
            i.Description = des;
            i.Price = prc;
            i.Quantity = quan;

            // Saving the Item
            ItemBL ibl = new ItemBL();
            ibl.saveItem(i);

        }

        public void getInputToUpdateItem()
        {
            //Getting input of Item Id to update its Content
            Console.WriteLine("Please Enter the Item Id you want to Update.  ");
            int idForItem = System.Convert.ToInt32(Console.ReadLine());
            ItemBL ibl = new ItemBL();

            // To get the item 
            ItemBO index = ibl.find(idForItem);

            // If Input is not enterd then it is default
            if(index.ItemID==default(int))
            {
                Console.WriteLine("Item not found.");
            }
            else
            {
                ItemBO bo = new ItemBO();
                Console.WriteLine("-------------------------------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine("{0,-15} {1,-37} {2,-19} {3,-21} {4}", "Item ID", "Description", "Price", "Quantity", "Creation Date");
                Console.WriteLine("-------------------------------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine("{0,-15} {1,-37} {2,-19:N0} {3,-21} {4}", index.ItemID, index.Description, index.Price, index.Quantity, index.CreationDate.ToString("dd/MM/yyyy"));

                Console.WriteLine("Enter the data to update in the field, if not necessary then leave it empty.");
                // Getting Input for the Item's Description
                Console.WriteLine("Enter Item's Description :");
                string des = Console.ReadLine();

                // Getting Input for the Item's Price
                Console.WriteLine("Enter Item's Price : ");
                decimal prc=default(decimal);
                try
                {
                   prc = System.Convert.ToDecimal(Console.ReadLine());

                }
                catch(Exception ex)
                {

                }

                //Getting Input for the Item's Quantity
                Console.WriteLine("Enter Item's Quantity : ");
                int quan=default(int);
                try
                {
                    quan= System.Convert.ToInt32(Console.ReadLine());

                }
                catch(Exception ex)
                {

                }

                // Item Object
                ItemBO i = new ItemBO();
                i.Description = des;
                i.Price = prc;
                i.Quantity = quan;

                ibl.updateItem(index.ItemID, i);

            }
        }

        public void findItem()
        {

            Console.WriteLine("Please specify atleast one of the following to find the item. Leave all fields blank to return to Items Menu:");
            Console.WriteLine("Enter Item's ID : ");
            int id = default(int);
            try
            {
                id = System.Convert.ToInt32(Console.ReadLine());
            }
            catch(Exception ex)
            {

            }
            // Getting Input for the Item's Description
            Console.WriteLine("Enter Item's Description :");
            string des = Console.ReadLine();
            if (des.Equals(String.Empty))
            {
                des = default(string);
            }
            // Getting Input for the Item's Price
            Console.WriteLine("Enter Item's Price : ");
            decimal prc = default(decimal);
            try
            {
                prc = System.Convert.ToDecimal(Console.ReadLine());

            }
            catch (Exception ex)
            {

            }

            //Getting Input for the Item's Quantity
            Console.WriteLine("Enter Item's Quantity : ");
            int quan = default(int);
            try
            {
                quan = System.Convert.ToInt32(Console.ReadLine());

            }
            catch (Exception ex)
            {

            }
            Console.WriteLine("Enter Item's Date (dd/MM/yyyy) : ");
            DateTime dateTime = default(DateTime);
            try
            {
                dateTime = System.Convert.ToDateTime(Console.ReadLine());
            }
            catch (Exception ex)
            {

            }
            ItemBO i = new ItemBO();
            i.ItemID = id;
            i.Description = des;
            i.Price = prc;
            i.Quantity = quan;
            i.CreationDate = dateTime;

            ItemBL itemBL = new ItemBL();
            
            // to find the item on the basis of item business object
            List<ItemBO> itemsFound = itemBL.findItems(i);
            if(itemsFound.Count==0)
            {
                Console.WriteLine("No Such Item Exist.");
            }
            else
            {
                Console.WriteLine("-------------------------------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine("{0,-15} {1,-37} {2,-19} {3,-21} {4}", "Item ID", "Description", "Price", "Quantity","Creation Date");
                Console.WriteLine("-------------------------------------------------------------------------------------------------------------------------------------------");
                foreach(ItemBO ibo in itemsFound)
                {
                    Console.WriteLine("{0,-15} {1,-37} {2,-19:N0} {3,-21} {4}", ibo.ItemID, ibo.Description, ibo.Price, ibo.Quantity,ibo.CreationDate.ToString("dd/MM/yyyy"));
                }
                Console.WriteLine("-------------------------------------------------------------------------------------------------------------------------------------------");
            }
        }

        public void getInputForDeleting()
        {
            Console.WriteLine("Please enter the Item Id you want to remove.");
            int id = default(int);
            try
            {
                id =System.Convert.ToInt32( Console.ReadLine());
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            ItemBL ibl = new ItemBL();
            ItemBO index = ibl.find(id);
            if(index.ItemID==default(int))
            {
                Console.WriteLine("No Such Item Exist");
            }
            else
            {
                ibl.deleteItem(index.ItemID);
            }
        }
    }
}
